'''3. Escreva um programa Python que recebe como dados de entrada o nome, a altura e o sexo (M ou
F) de uma pessoa, e calcula e o peso ideal dessa pessoa, utilizando as seguintes fórmulas:
• sexo masculino: peso ideal = (72.7 * altura) - 58
• sexo feminino: peso ideal = (62.1 * altura) - 44.7
'''
nome = str(input('Seu nome: '))
altura = float(input('Sua Altura, em metros: '))
sexo = str(input('Seu sexo: [M/F] ')).strip().upper()[0]
if sexo == 'M':
    sexomasculino = pesoideal = (72.7 * altura) - 58
    print(f'Olá {nome}, seu peso-ideal é {sexomasculino} Kg')
elif sexo == 'F':
    sexofeminino = pesoideal = (62.1 * altura) - 44.7
    print(f'Olá {nome}, seu peso-ideal é {sexofeminino} Kg')