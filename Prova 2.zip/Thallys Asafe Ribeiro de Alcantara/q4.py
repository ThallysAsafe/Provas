'''4. Um hotel cobra R$ 150.00 por diária e mais uma taxa de serviços que é cobrada como descrito
abaixo. Construa um programa que recebe a quantidade de dias que um hóspede irá usar e imprime o
valor a ser cobrado.
• R$ 7.50 por diária, se o número de diárias for maior que 5
• R$ 9.00 por diária, se o número de diárias for igual a 5
• R$ 10.50 por diária, se o número de diárias for menor que 5.
'''
dias = int(input('Quantos dias iram ficar no hotel: '))
tfixa = 150
if dias < 5:
    conta = (tfixa + 10.50) * dias
elif dias == 5: 
    conta = (tfixa + 9.00) * dias
elif dias > 5:
    conta = (tfixa + 7.50) * dias
print(f'O valor total da hospedagem, incluindo taxas de serviços fica por R${conta}')
