'''2. Uma empresa quer vericar se um empregado está qualicado para a aposentadoria ou não. Para
estar em condições de se aposentar, pelo menos um dos dos segintes critérios deve ser satisfeito:
• Ter no mínimo 65 anos
• Ter trabalhado no mínimo 30 anos 
Ter no mínimo 60 anos e ter trabalhado no mínimo 25
Com base nessas informações, faça uma algoritmo que receba a idade de um empregado e o número
de anos de trabalho. O algoritmo deve imprimir se o empregado pode ser aposentado ou não
'''
idade = int(input('Qual a sua idade: '))
anostb = int(input('Quantos anos trabalhados: '))
if idade >= 65 or anostb >= 30:
    print('Pode se aposentar')
elif idade >= 60 and anostb >= 25:
    print('Pode se aposentar')
else:
    print('Não pode se aposentar')
