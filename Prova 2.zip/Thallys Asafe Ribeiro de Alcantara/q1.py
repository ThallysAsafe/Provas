'''1. A jornada de trabalho semanal de um funcionário é de 40 horas. O funcionário que trabalhar
mais de 40 horas receberá hora extra, cujo cálculo é o valor da hora regular com um acréscimo de 50%.
Escreva um algoritmo que leia o número de horas trabalhadas em uma semana, o salário por hora e
escreva o salário total do funcionário na semana, que deverá ser acrescido das horas extras, caso tenham sido trabalhadas
'''
horas = int(input('Quantas horas foram trabalhadas nesta semana: '))
salario = float(input('Quanto é o seu salário por hora: '))
if horas > 40 and salario >= 0:
    extra = horas - 40
    salext = extra * (salario*1.5)
    salsem = salario * horas + salext
    print(f'O seu salário é R${salsem}, devido a {extra}h de hora extra!')
elif horas >= 0 and salario >= 0: 
    salsem = salario * horas
    print(f'O seu salário é R${salsem}!')
else:
    print('Entrada Inválida!')

