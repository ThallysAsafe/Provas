# 1. Uma tarefa muito comum em sistemas web é a realização do login dos usuários autorizados a
# acessar o sistema. De modo a realizar a autenticação, o sistema guarda os dados de nome, email e senha
# de todos os usuários cadastrados. Quando um novo usuário precisa realizar o login, este usuário envia,
# via formulário, o email e senha cadastrados. O sistema então verifica se esse usuário está realmente
# cadastrado e verifica se a senha cadastrada é igual a senha enviada pelo usuário. Implemente um programa que possua a lista de usuários (nome, email e senha) e que possua uma função de autenticação que recebe email e senha e informa se o login foi realizado ou não.
# Ex:
# Usuário Email Senha
# Ana ana@gmail.com ana123
# Bob bob@hotmail.com 123bob
# Claudio claudio@bol.com clau!*

# {bob@hotmail.com, 123bob}: Autenticado
# {claudio@bol.com, 123claudio}: Não autenticad
login = [{"Email": "bob@hotmail.com", "Senha": "123bob"}]
def autenticação(login):
    condicao = False
    cadastrados = [{"Usuario": "Ana", "Email": "ana@gmail.com", "Senha": "ana123"},{"Usuario": "Bob", "Email": "bob@hotmail.com","Senha": "123bob"},{"Usuario": "Claudio", "Email": "claudio@bol.com","Senha": "clau!*"}]
    for i in range(len(login)):
        # acessar cada lista dentro da lista
        for j in range(0,len(cadastrados[0])):
            if login[i]['Email'] == cadastrados[j]['Email']:
                condicao = True
                if login[i]['Senha'] == cadastrados[j]['Senha']:
                    print(f'{login[i]}: Autenticado') 
        if condicao == False:
            print(f'{login[i]}: Não Autenticado') 
            
autenticação(login)