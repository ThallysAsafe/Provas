A  = [['X','O','X'],
      ['O','X','O'],
      ['O','O','X']]

def jogodavelha(A):
    m = len(A)
    n = len(A[0])
    pontoX = 0
    pontoO = 0
    for i in range(m):
        for j in range(n):
            if A[i][j] == 'X':
                pontoX += 1
                if pontoX == 3:
                    resultado = 'X vencedor'
                    return resultado 
            elif A[i][j] == 'O':
                pontoO += 1
                if pontoO == 3:
                    resultado = 'O vencedor'
                    return resultado
        pontoO = 0
        pontoX = 0
    for i in range(n):
        for j in range(m):
            if A[j][i] == 'X':
                pontoX += 1
                if pontoX == 3:
                    resultado = 'X vencedor'
                    return resultado 
            elif A[j][i] == 'O':
                pontoO += 1
                if pontoO == 3:
                    resultado = 'O vencedor'
                    return resultado
        pontoO = 0
        pontoX = 0
    i = 0 
    for i in range(m):
        if A[i][i] == 'X':
            pontoX += 1
            print(i)
            if pontoX == 3:
                resultado = 'X vencedor'
                return resultado 
        elif A[i][i] == 'O':
            pontoO += 1
            if pontoO == 3:
                resultado = 'O vencedor'
                return resultado
    resultado = 'empate'
    return resultado
print(jogodavelha(A))
    